%% Another one
% Testing it out
%% viz 1
pcolor( rand(100));
snapnow;
%% viz 2
pcolor( rand(100));
snapnow;
