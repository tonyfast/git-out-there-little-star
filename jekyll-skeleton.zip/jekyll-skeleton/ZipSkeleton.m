fn = dir('.');

exc = {'_site','.git','*~','.','..'};

